<div align="center">
<img src="https://cdn.discordapp.com/avatars/510736807999307786/a_2c72b8005b10ef5ecdbdcdde1f391ba2.gif?size=4096">
</div>
  
<div align="center">

<h1>Hey, I'm <a href="https://scoopydev.xyz" target="_blank">Seif Wessam</a>! 👋</h1>
  <img src="https://lanyard-profile-readme.vercel.app/api/510736807999307786" height="280">
</div>
<br>
<br>
<br>

<h1 align="center"> ❓ About me</h1>
<p align="center">I'm a young programmer who loves to learn new things and also very curious about everything.</p>
<p align="center">I was born in Egypt and I currently still live in Egypt.</p>
<p align="center">I love Python, HTML and Node.JS</p>
<p align="center">I use <a href="https://discord.com" target="_blank">Discord</a> & <a href="https://revolt.chat" target="_blank">Revolt</a> to communicate and chat.</p>
<h4 align="center">• What is Discord?</h4>
<p align="center">Discord is a social chatting platform for gamers and everything else.</p>
<h4 align="center">• What is Revolt?</h4>
<p align="center">Revolt is a newly made social chatting platform that got many features to support programmers.</p>
<br>
<p align="center">You can reach me out via <a href="mailto:seif.wessam66@gmail.com">mail</a> or <a href="https://twitter.com/ScopesCodez" target="_blank">Twitter</a></p>

# 📚 Experiences  

- **Developer and project manager @ [GlobalX](https://globalx-bot.xyz)** • *September 25/2021 - Now*

    I currently work at GlobalX and other affiliated projects related to Discord and Discord bots.
    
    My job at GlobalX is to maintain all the bots and services, manage the team, lead the co-lead the project and programming the Discord bots.
    
    GlobalX is a global banning Discord bot that keeps bad individuals with previous records on our database from joining Discord servers that use GlobalX to protect those servers from these users.
    
    I also act as a public representive on all our social medias.
    
- **Leader, developer, project leader and CEO @ [Scopes](https://scopes.cf)** • *November 10/2018 - Now*

  My job is to maintain, update and administrate the Discord bot "Scopes".
  
  Scopes is a Discord bot that will help you manage your Discord server and it features almost eveything.
  
- **Site moderator and Bots reviewer @ [StellarBotList](https://stellarbotlist.com)** • *July 30/2021 - Now*

  I review Discord bots at stellar bot list and handle opened notes.
  
  Stellar Bot List is a Discord bots list where you can submit your Discord bot, then it goes through a verification process and then it's either approved or denied.

#### 📊 Activity

<!--START_SECTION:waka-->
```text
HTML         9 hrs 14 mins   ██████████▒░░░░░░░░░░░░░░   40.71 % 
JavaScript   4 hrs 37 mins   █████░░░░░░░░░░░░░░░░░░░░   20.40 % 
Python       4 hrs 15 mins   ████▓░░░░░░░░░░░░░░░░░░░░   18.80 % 
CSS          4 hrs 12 mins   ████▓░░░░░░░░░░░░░░░░░░░░   18.55 % 
JSON         16 mins         ▒░░░░░░░░░░░░░░░░░░░░░░░░   01.24 % 
```
<!--END_SECTION:waka-->

#### 🌟 Other stuff
![Metrics](https://metrics.lecoq.io/ScopesCodez?template=classic&repositories=10&repositories.batch=10&base.header=0&base.activity=0&base.community=0&base.repositories=0&base.metadata=0&tweets=1&repositories=1&repositories=10&repositories.batch=10&repositories.forks=false&repositories.affiliations=owner&repositories.featured=ScopesCodez%2Fdiscordpy-cogs%2C%20ScopesCodez%2Fdiscordpy-pagination%2C%20ScopesCodez%2Fdiscordpy-eval-command&tweets.attachments=true&tweets.limit=3&tweets.user=ScopesCodez&config.timezone=Africa%2FCairo)
